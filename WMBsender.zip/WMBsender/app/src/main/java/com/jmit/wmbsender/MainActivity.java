package com.jmit.wmbsender;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    public static Context context;
    Button btnStartService, btnStopService;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setTitle("WMB -- open beta 1.0.0");
        context=this;

        btnStartService = findViewById(R.id.buttonStartService);
        btnStopService = findViewById(R.id.buttonStopService);

        btnStartService.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startService();
            }
        });

        btnStopService.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                stopService();
            }
        });

        /**
         * @author
         * lakshay dutta
         *
         * This code starts a new background service. Note that services can be killed by the operating system
         */

        /*Intent intent = new Intent(MainActivity.this , LocationSendingService.class);
        startService(intent);*/

    }

    public void startService() {
        Intent serviceIntent = new Intent(this, LocationSendingService.class);
        serviceIntent.putExtra("inputExtra", "Thank you for helping for the beta release");

        ContextCompat.startForegroundService(this, serviceIntent);
    }

    public void stopService() {
        Intent serviceIntent = new Intent(this, LocationSendingService.class);
        stopService(serviceIntent);
    }
}
